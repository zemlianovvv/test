
# Business as a System
---
---
карта 
<https://miro.com/app/board/o9J_kxviOm0=/?moveToWidget=3074457346595003814>

<https://www.facebook.com/kirilllkazakov>

карта
<http://map-of-design.com/?utm_referrer=http%3a%2f%2fmap-of-design.com%2fkirill-kazakov>
![[Evernote/MARKETING/Marketing tools_2/_resources/Бизнес_это_система.resources/Снимок экрана 2019-09-18 в 11.01.39.png]]
Есть курсы
<http://map-of-design.com/management#Stoimost>

Есть консультации 
<http://map-of-design.com/kirill-kazakov>

<https://vc.ru/finance/72390-skolko-biznes-mozhet-zarabotat-deneg-i-prichem-tut-pylesos>
Давайте начнем с абстрактного. С точки зрения физики путь от «Отсутствия денежных средств» до «Наличие денежных средств» является изменением состояния системы.
![[Evernote/MARKETING/Marketing tools_2/_resources/Бизнес_это_система.resources/Снимок экрана 2019-09-18 в 11.12.14.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Бизнес_это_система.resources/Снимок экрана 2019-09-18 в 11.01.47.png]]
