
# Bain Value Pyramids for B2B and B2C
---
---
<http://www2.bain.com/bainweb/media/interactive/elements-of-value/#>

<http://www2.bain.com/bainweb/media/interactive/b2b-eov/index.html#>

![[original-1je2.png]]

![[Снимок экрана 2019-12-07 в 16.49.00.png]]

![[Снимок экрана 2019-12-07 в 16.49.42.png]]
