
# Business Model and Positioning Template
---
---
![[2017-07-10_17-50-28.png]]
