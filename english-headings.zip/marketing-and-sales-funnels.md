---
source: https://www.facebook.com/DigitalCup/photos/a.900699153398685.1073741834.784741258327809/914767925325141/?type=3&theater
---

# Marketing and Sales Funnels
## 1. Sales Funnel Basics

На английском данный термин звучит как «purchase funnel», «sales funnel» или «sales pipeline»: данный термин является базовым для маркетинга.

> _**Воронка продаж**_ _— это путь, проходимый обычным потребителем товара либо услуги, от привлечения его внимания к какому-либо предложению до момента приобретения._

По прошествии 30 лет данное понятие успешно совместили с другой общеизвестной концепцией торговли – **AIDA**:

* внимание (attention);

* интерес (interest);
* желание (desire);
* действие (action).
С этого времени понятие **воронки продаж** стало являться одним из базовых маркетинговых терминов.
Это значит, что покупке товара или услуги предшествует **4 фазы готовности клиента:**

* привлекается его внимание (к примеру, инструментами рекламы);

* пробуждение интереса (содержанием рекламного предложения);
* возбуждение у покупателя желания воспользоваться данным предложением;
* «клиент созрел» (звонок покупателя в компанию, визит в магазин или на интернет-ресурс).

![[17492630_914767925325141_1194856467437846841_o.png]]

![[marketing-voronka.jpg]]

![[pic1.Conversion.jpg]]

![[29ff90153f.gif]]

![[marketing-funnel-diagram-1024x569.png]]

![[39236311-infographic-or-web-design-template.jpg]]

![[img-1411141835.jpg]]

![[voronka_prodaj_21.jpg]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.1.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.2.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.3.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.4.png]]![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.5.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.6.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.7.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.8.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.9.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.10.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.11.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.12.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.13.png]]

Вкратце план действий таков (каждый пункт отмечен на предварительной CJM LiveTex):
1) Определите основные группы покупателей. Для каждого профиля покупателя лучше всего составить отдельную карту.
2) Составьте воронку продаж для каждой группы.
3) Определите цели клиента на каждом этапе.
4) Отметьте точки взаимодействия клиента и компании в различных каналах: соцсети, сайт компании, мобильное приложение и т. п. В результате у вас получится experience map, на которой опционально можно построить эмоциональную карту (6) для каждой точки контакта.
5) Выделите KPI для каждого этапа — то, чего вам хотелось бы достичь.
7) Найдите уязвимые места — препятствия, которые мешают достижению KPI. Потом необходимо будет дать рекомендации по их устранению.

![[Снимок экрана 2017-11-20 в 22.28.11.png]]

* установление контакта;
* выявление потребностей клиента;
* презентация предлагаемого товара;
* работа с возражениями клиента;
* завершение сделки.

![[Снимок экрана 2017-11-20 в 22.56.26.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.14.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.15.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.16.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.17.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.18.png]]![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.19.png]]

![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.20.png]]![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.21.png]]![[Evernote/MARKETING/Marketing tools_2/_resources/Маркетинговая_воронка,_воронка_продаж,_отдел_продаж.resources/unknown_filename.22.png]]![[Снимок экрана 2017-11-20 в 22.59.28.png]]
