
# Marketing in a Few Words
---
---
![[Evernote Snapshot 20200115 114653.png]]

![[Evernote Snapshot 20200115 114653.1.png]]

![[Evernote Snapshot 20200115 114653.2.png]]
