---
source: http://www.maksimus.pro/wp-content/uploads/2013/11/SHablon-personal-noi-biznes-modeli-rie-ltora.png
---

# Business Model Templates
<http://bizmodelgu.ru/category/biz-modeling/>   - крутой ресурс по бизнес моделированию

<http://cpa-master.com/4-business-modeling-tools> инструменты бизнес планирование 

<http://rzbpm.ru/knowledge/instrumenty-upravleniya-i-modelirovaniya-biznes-processov.html><http://rzbpm.ru/knowledge/instrumenty-upravleniya-i-modelirovaniya-biznes-processov.html>

<http://rzbpm.ru/knowledge/instrumenty-upravleniya-i-modelirovaniya-biznes-processov.html>
<http://rzbpm.ru/knowledge/instrumenty-upravleniya-i-modelirovaniya-biznes-processov.html>

![[SHablon-personal-noi-biznes-modeli-rie-ltora.png.jpg]]

![[2017-01-14_18-58-55.png]]

![[2017-01-14_19-03-20.png]]

![[2017-01-14_19-01-53.png]]

![[2017-01-14_19-04-17.png]]

![[82acc423dd084c8e874219c7c052030c.png]]

![[2017-01-14_18-57-58.png]]

![[2017-01-14_19-11-16.png]]![[2017-01-14_19-08-32.png]]

![[2017-01-14_19-12-39.png]]
